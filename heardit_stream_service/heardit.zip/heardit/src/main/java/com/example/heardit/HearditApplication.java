package com.example.heardit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HearditApplication {

	public static void main(String[] args) {
		SpringApplication.run(HearditApplication.class, args);
	}

}
