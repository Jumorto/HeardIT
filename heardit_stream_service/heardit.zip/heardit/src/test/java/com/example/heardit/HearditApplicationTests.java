package com.example.heardit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HearditApplicationTests {

	@Test
	void contextLoads() {
	}

}
